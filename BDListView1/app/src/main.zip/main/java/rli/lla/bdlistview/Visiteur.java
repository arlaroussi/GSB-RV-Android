package rli.lla.bdlistview;

public class Visiteur {

    String code = null;
    String nom= null;
    String prenom = null;
    String login = null;

    public String getCode() {
        return code;
    }
    public void setCode(String code) {
        this.code = code;
    }
    public String getNom() {
        return nom;
    }
    public void setName(String nom) {
        this.nom = nom;
    }
    public String getPrenom() {
        return prenom;
    }
    public void setPrenom(String prenom) {
        this.prenom = prenom;
    }
    public String getLogin() {
        return login;
    }
    public void setRegion(String login) {
        this.login = login;
    }


}
